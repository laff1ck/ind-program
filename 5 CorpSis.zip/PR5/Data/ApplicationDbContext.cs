﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using PR5.Models;
using System;

namespace PR5.Data
{
    public class ApplicationDbContext : IdentityDbContext<IdentityUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<Grade> Grades { get; set; }
        public DbSet<Achievement> Achievements { get; set; }
        public DbSet<Teacher> Teachers { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            var hasher = new PasswordHasher<IdentityUser>();

            var user1 = new IdentityUser
            {
                Id = "1",
                UserName = "student1",
                NormalizedUserName = "STUDENT1",
                Email = "student1@example.com",
                NormalizedEmail = "STUDENT1@EXAMPLE.COM",
                EmailConfirmed = true,
                SecurityStamp = Guid.NewGuid().ToString("D"),
                ConcurrencyStamp = Guid.NewGuid().ToString("D"),
                PasswordHash = hasher.HashPassword(null, "Password1!")
            };

            var user2 = new IdentityUser
            {
                Id = "2",
                UserName = "student2",
                NormalizedUserName = "STUDENT2",
                Email = "student2@example.com",
                NormalizedEmail = "STUDENT2@EXAMPLE.COM",
                EmailConfirmed = true,
                SecurityStamp = Guid.NewGuid().ToString("D"),
                ConcurrencyStamp = Guid.NewGuid().ToString("D"),
                PasswordHash = hasher.HashPassword(null, "Password2!")
            };

            modelBuilder.Entity<IdentityUser>().HasData(user1, user2);

            modelBuilder.Entity<Achievement>().HasData(
                new Achievement { Id = 1, UserId = "1", Date = new DateTime(2024, 1, 15), Type = "Учёба", Description = "Занял 1-место по олимпиаде" },
                new Achievement { Id = 2, UserId = "1", Date = new DateTime(2024, 3, 10), Type = "Спорт", Description = "Занял первое место на турнире по баскетболу" },
                new Achievement { Id = 3, UserId = "2", Date = new DateTime(2024, 5, 20), Type = "Наука", Description = "Представил научную работу на национальной конференции" },
                new Achievement { Id = 4, UserId = "2", Date = new DateTime(2024, 6, 18), Type = "Спорт", Description = "Участвовал в марафоне и занял 2-е место" }
            );

            modelBuilder.Entity<Grade>().HasData(
                new Grade { Id = 1, UserId = "1", Semester = 1, Subject = "Иностранный язык", Score = "5" },
                new Grade { Id = 2, UserId = "1", Semester = 1, Subject = "Экономическая культура", Score = "4" },
                new Grade { Id = 3, UserId = "1", Semester = 2, Subject = "Программирование", Score = "5" },
                new Grade { Id = 4, UserId = "1", Semester = 2, Subject = "Физика", Score = "4" },
                new Grade { Id = 5, UserId = "2", Semester = 1, Subject = "Безопасность жизнедеятельности", Score = "5" },
                new Grade { Id = 6, UserId = "2", Semester = 1, Subject = "Большие данные", Score = "3" },
                new Grade { Id = 7, UserId = "2", Semester = 2, Subject = "Теория вероятностей", Score = "4" },
                new Grade { Id = 8, UserId = "2", Semester = 2, Subject = "Математический анализ", Score = "5" }
            );

            modelBuilder.Entity<Teacher>().HasData(
                new Teacher { Id = 1, UserId = "1", Name = "Иван Иванов", Subject = "Математика", Department = "Физико-математический факультет" },
                new Teacher { Id = 2, UserId = "1", Name = "Петр Петров", Subject = "Английский язык", Department = "Гуманитарный факультет" },
                new Teacher { Id = 3, UserId = "2", Name = "Сидор Сидоров", Subject = "Физика", Department = "Физико-математический факультет" },
                new Teacher { Id = 4, UserId = "2", Name = "Мария Маркина", Subject = "Химия", Department = "Физико-математический факультет" }
            );
        }
    }
}
