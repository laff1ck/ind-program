﻿namespace PR5.Models
{
    public class Teacher
    {
        public int Id { get; set; }
        public string UserId { get; set; }
        public string Name { get; set; }
        public string Subject { get; set; }
        public string Department { get; set; }
    }
}
