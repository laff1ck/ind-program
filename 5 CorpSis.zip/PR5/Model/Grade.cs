﻿namespace PR5.Models
{
    public class Grade
    {
        public int Id { get; set; }
        public string UserId { get; set; }
        public int Semester { get; set; }
        public string Subject { get; set; }
        public string Score { get; set; }
    }
}
