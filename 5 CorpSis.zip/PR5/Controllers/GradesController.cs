﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PR5.Data;
using PR5.Models;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace PR5.Controllers
{
    [Authorize]
    public class GradesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public GradesController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(string searchString)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            var grades = from g in _context.Grades
                         where g.UserId == userId
                         select g;

            if (!string.IsNullOrEmpty(searchString))
            {
                grades = grades.Where(g => g.Subject.Contains(searchString));
            }

            return View(await grades.ToListAsync());
        }
    }
}
