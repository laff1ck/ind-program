﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PR5.Data;
using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;

namespace PR5.Controllers
{
    [Authorize]
    public class AchievementsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AchievementsController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(string sortOrder, string searchString, string typeFilter)
        {
            ViewData["DateSortParm"] = String.IsNullOrEmpty(sortOrder) ? "date_desc" : "";
            ViewData["CurrentFilter"] = searchString;
            ViewData["CurrentTypeFilter"] = typeFilter;

            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var achievements = from a in _context.Achievements
                               where a.UserId == userId
                               select a;

            if (!String.IsNullOrEmpty(searchString))
            {
                achievements = achievements.Where(a => a.Description.Contains(searchString));
            }

            if (!String.IsNullOrEmpty(typeFilter))
            {
                achievements = achievements.Where(a => a.Type == typeFilter);
            }

            switch (sortOrder)
            {
                case "date_desc":
                    achievements = achievements.OrderByDescending(a => a.Date);
                    break;
                default:
                    achievements = achievements.OrderBy(a => a.Date);
                    break;
            }

            return View(await achievements.AsNoTracking().ToListAsync());
        }
    }
}
