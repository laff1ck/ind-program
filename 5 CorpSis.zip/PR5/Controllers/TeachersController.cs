﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PR5.Data;
using System;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace PR5.Controllers
{
    [Authorize]
    public class TeachersController : Controller
    {
        private readonly ApplicationDbContext _context;

        public TeachersController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(string sortOrder)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            ViewBag.NameSortParm = String.IsNullOrEmpty(sortOrder) ? "name_desc" : "";
            ViewBag.SubjectSortParm = sortOrder == "Subject" ? "subject_desc" : "Subject";
            ViewBag.DepartmentSortParm = sortOrder == "Department" ? "department_desc" : "Department";

            var teachers = from t in _context.Teachers
                           where t.UserId == userId
                           select t;

            switch (sortOrder)
            {
                case "name_desc":
                    teachers = teachers.OrderByDescending(t => t.Name);
                    break;
                case "Subject":
                    teachers = teachers.OrderBy(t => t.Subject);
                    break;
                case "subject_desc":
                    teachers = teachers.OrderByDescending(t => t.Subject);
                    break;
                case "Department":
                    teachers = teachers.OrderBy(t => t.Department);
                    break;
                case "department_desc":
                    teachers = teachers.OrderByDescending(t => t.Department);
                    break;
                default:
                    teachers = teachers.OrderBy(t => t.Name);
                    break;
            }

            return View(await teachers.AsNoTracking().ToListAsync());
        }
    }
}
